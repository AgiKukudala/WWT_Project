Once you run all the code in Visual Studio start with the student.html
You'll see a login link at the very bottom(its a very small)\
The username is admin password= adminpass
That'll get you to the editable calendar
The changes made there apply to the student view.
You need all of these files.
